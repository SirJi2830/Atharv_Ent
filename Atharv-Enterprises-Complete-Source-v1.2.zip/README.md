# Atharv Enterprises — Complete Android Source

**App version:** 1.2 (versionCode 3)  
**Package ID:** `com.atharventerprises.app`  
**Minimum Android:** Android 6.0 (API 23)  
**Build:** Android WebView app with offline local storage

This is the complete source project for building the Atharv Enterprises Android APK. It includes the Android app source, HTML application, logo and launcher icon resources, Gradle configuration, and a GitHub Actions workflow.

## Included app modules

- Dashboard and project overview
- Project register (client/department, location, contract amount, dates, status and notes)
- Expenses and payments
- Material purchase / inward register
- Material consumption register with project-wise stock balance and insufficient-stock validation
- Fuel purchase register (diesel, petrol, lubricant/engine oil and other; quantity, rate, amount, vendor and bill number)
- Fuel consumption / issue register (project, machine/vehicle, registration number, hour meter/odometer and operator)
- Fuel stock balance with insufficient-stock validation
- Machinery / equipment usage log
- Project financial summary, print / Save as PDF and CSV export
- Full JSON backup and restore
- Offline use; records are stored locally on the device

## Build APKs with GitHub Actions (mobile-friendly)

1. Download and extract this complete ZIP.
2. In your GitHub repository, upload **all contents inside** the extracted `Atharv-Enterprises-Complete-Source` folder. Keep the folder named `atharv-android` and the `.github/workflows/android-build.yml` path intact. Do not upload only the outer ZIP if you want GitHub Actions to see the workflow.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab and select **Build Atharv Enterprises APKs**. The workflow also runs automatically after a push to `main`.
5. Open the completed workflow run. Under **Artifacts**, download `Atharv-Enterprises-APKs` and extract it. It contains the Debug and Release APKs.

## Build locally with Android Studio

1. Extract this ZIP.
2. Open the `atharv-android` folder in Android Studio.
3. Allow Gradle sync to complete with JDK 17 and Android SDK 35 installed.
4. Build > Build Bundle(s) / APK(s) > Build APK(s), or run `assembleDebug` / `assembleRelease`.

The project intentionally uses a Gradle installation supplied by Android Studio or GitHub Actions; a Gradle wrapper is not included in this source bundle.

## Important data and signing notes

- App records are stored locally in the app's WebView storage on that device. Export a JSON backup before uninstalling, clearing app data, or changing devices. Restoring a backup replaces the current local records.
- CSV is an Excel-compatible export; JSON is the complete backup/restore format.
- The Release build is signed with the CI runner's debug signing key for convenient testing. It is not a production signing key. For long-term distribution and seamless upgrades, configure a private, persistent release keystore and protect its credentials in GitHub Actions secrets.
- The source package is provided for building. An APK is not included in this ZIP; GitHub Actions creates APK artifacts after a successful build.

## Project layout

```text
.github/workflows/android-build.yml
README.md
CHANGELOG.md
atharv-android/
  settings.gradle.kts
  build.gradle.kts
  gradle.properties
  app/build.gradle.kts
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/atharventerprises/app/MainActivity.java
  app/src/main/assets/index.html
  app/src/main/assets/atharv-logo.png
  app/src/main/res/...
```
