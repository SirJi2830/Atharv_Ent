# Changelog

## 1.2 — Complete source bundle

- Packaged the complete Android Studio project and GitHub Actions workflow together.
- Included material purchase / stock and material consumption screens.
- Included fuel purchase and fuel consumption records with project-wise stock validation.
- Included the full offline project, expense, payment, machinery, reports, CSV export and JSON backup/restore app.
- Updated the Materials screen guidance so it accurately describes the Consumption tab.
- Increased Android versionCode to 3 and versionName to 1.2.

## 1.1

- Android WebView shell, offline app assets, logo branding and GitHub APK build workflow.
